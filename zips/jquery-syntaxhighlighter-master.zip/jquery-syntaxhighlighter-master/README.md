## jQuery Syntax Highlighter

jQuery Extension for [Google's Prettify Syntax Highlighter](http://code.google.com/p/google-code-prettify/)


## Usage

Refer to the [demo](http://balupton.github.com/jquery-syntaxhighlighter/demo/) for usage instructions


## History

You can discover the history inside the [History.md](https://github.com/balupton/jquery-syntaxhighlighter/blob/master/History.md#files) file


## License

Licensed under the [MIT License](http://creativecommons.org/licenses/MIT/)
<br/>Copyright &copy; 2010 [Benjamin Arthur Lupton](http://balupton.com)
